function scale_practice
rng('shuffle');

%% Turn off Screen Warnings %%
Screen('Preference', 'SkipSyncTests', 2 );
Screen('Preference', 'SuppressAllWarnings', 1);
KbName('UnifyKeyNames');

%% Check for Psychtoolbox %%
try
    ptbVersion = PsychtoolboxVersion;
catch
    url = 'https://github.com/Psychtoolbox-3/Psychtoolbox-3';
    fprintf('Psychophysics Toolbox may not be installed or in your search path.\nSee: %s\n', url);
end

%% DEFAULTS %%
defaults = task_defaults;
trigger = KbName(defaults.trigger);
addpath(defaults.path.utilities)

%% Setup Input Device(s) %%
switch upper(computer)
    case 'MACI64'
        inputDevice = ptb_get_resp_device;
    case {'PCWIN','PCWIN64'}
        % Do nothing for now - return empty chosen_device
        % Windows merges keyboard input and will process correctly
        inputDevice = [];
    otherwise
        % Do nothing - return empty chosen_device
        inputDevice = [];
end
resp_set = ptb_response_set([defaults.valid_keys defaults.escape]); % response set

%% Initialize Screen %%
try
    w = ptb_setup_screen(0,250,defaults.font.name,defaults.font.size1, defaults.screenres); % setup screen
catch
    disp('Could not change to recommend screen resolution. Using current.');
    w = ptb_setup_screen(0,250,defaults.font.name,defaults.font.size1);
end
screenRect = [0;0;w.xcenter*2;w.ycenter*2];

%% Make Images Into Textures %%
instructTex = Screen('MakeTexture', w.win, imread([defaults.path.stim filesep 'instruction.jpg']));
fixTex = Screen('MakeTexture', w.win, imread([defaults.path.stim filesep 'fixation.jpg']));

%==========================================================================
%
% START TASK PRESENTATION
%
%==========================================================================

%% Present Instruction Screen %%
Screen('DrawTexture',w.win, instructTex, [], screenRect); Screen('Flip',w.win);

%% Wait for Trigger to Begin %%
DisableKeysForKbCheck([]);
secs=KbTriggerWait(trigger,inputDevice);
anchor=secs;

try
    vals = [1 9 7 3 8 2];
    for i = 1:6
        
        scaleStart = GetSecs - anchor;
        
        prompt = sprintf('Select the value %d',vals(i));
        scaleText = {'     1     ' '     5     ' '     9     '};
        numEls = 9;
        respWin = 5;
        
        [rating,rt] = ptb_circleLikert(w, defaults, inputDevice, resp_set, prompt, scaleText, numEls, respWin);%, startPoint, colors)
        
        WaitSecs('UntilTime', anchor + scaleStart + respWin);
        
        Screen('DrawTexture',w.win, fixTex, [], screenRect); Screen('Flip',w.win);
        WaitSecs(1);
        
    end
catch
    
    sca; rmpath(defaults.path.utilities)
    psychrethrow(psychlasterror);
    
end;

sca; rmpath(defaults.path.utilities)


end
