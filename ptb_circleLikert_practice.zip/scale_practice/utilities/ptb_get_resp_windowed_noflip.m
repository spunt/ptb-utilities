function [resp rt] = ptb_get_resp_windowed_noflip(resp_device, resp_set, resp_window)
% PTB_GET_RESP_WINDOWED Psychtoolbox utility for acquiring responses
%
% USAGE: [resp rt] = ptb_get_resp_windowed_noflip(resp_device,resp_set,resp_window)
%
% INPUTS 
%  resp_device = device #
%  resp_set = array of keycodes (from KbName) for valid keys
%  resp_window = response window (in secs)
%
% OUTPUTS
%  resp = name of key press (empty if no response)
%  rt = time of key press (in secs)
%
% Written by Bob Spunt, Jan. 7, 2013
% =========================================================================
onset = GetSecs;
noresp = 1;
resp = [];
rt = [];
while noresp && GetSecs - onset < resp_window
    
    [keyIsDown secs keyCode] = KbCheck(resp_device);
    keyPressed = find(keyCode);
    if keyIsDown & ismember(keyPressed, resp_set)
        
        rt = secs - onset;
        resp = KbName(keyPressed);
        noresp = 0;
        
    end
    
end